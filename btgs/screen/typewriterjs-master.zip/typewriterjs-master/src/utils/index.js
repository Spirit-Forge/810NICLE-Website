export { default as doesStringContainHTMLTag } from './does-string-contain-html-tag';
export { default as getDOMElementFromString } from './get-dom-element-from-string';
export { default as getRandomInteger } from './get-random-integer';
export { default as addStyles } from './add-styles';